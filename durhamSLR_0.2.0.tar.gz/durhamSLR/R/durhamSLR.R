#' The durhamSLR package
#'
#' Data for Statistical Learning modules at Durham University.
#'
#' @docType package
#'
#' @author Sarah Heaps \email{sarah.e.heaps@durham.ac.uk}
#'
#' @name durhamSLR
NULL
